package com.edo.fruitku;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

public class ListFruit extends RecyclerView.Adapter<ListFruit.ListViewHolder> {


    private ArrayList<FruitArchitecture> listFruit;

    private OnItemClickCallback onItemClickCallback;

    public ListFruit(ArrayList<FruitArchitecture> list) {
        this.listFruit = list;
    }

    public void setOnItemClickCallback(OnItemClickCallback onItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback;
    }

    @NonNull
    @Override
    public ListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_row_fruit, parent, false);
        return new ListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ListViewHolder holder, int position) {
        FruitArchitecture nw = listFruit.get(position);

        Glide.with(holder.itemView.getContext())
                .load(nw.getPhoto())
                .apply(new RequestOptions().override(60, 60))
                .into(holder.imgFruit);
        holder.tvNickName.setText(nw.getNickName());


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClickCallback.onItemClicked(listFruit.get(holder.getAdapterPosition()));
            }
        });
    }

    @Override
    public int getItemCount() {
        return listFruit.size();
    }

    public class ListViewHolder extends RecyclerView.ViewHolder{
        ImageView imgFruit;
        TextView tvFullName, tvNickName, tvDetail;


        public ListViewHolder(@NonNull View itemView) {
            super(itemView);
            imgFruit = itemView.findViewById(R.id.tv_fruit_photo);
            tvFullName = itemView.findViewById(R.id.tv_full_name);
            tvNickName = itemView.findViewById(R.id.tv_nick_name);
            tvDetail = itemView.findViewById(R.id.tv_detail);


        }
    }

    public interface OnItemClickCallback {
        void onItemClicked(FruitArchitecture data);
    }


}


