package com.edo.fruitku;

import java.util.ArrayList;

public class FruitsData {

    private static String[] fruitFullName = {
            "APEL",
            "ANGGUR",
            "BUAH NAGA",
            "DURIAN",
            "JAMBU",
            "KIWI",
            "MANGGA",
            "MELON",
            "STRAWBERY",
            "PISANG"

    };

    private static String[] fruitNickName = {
            "APEL",
            "ANGGUR",
            "BUAH NAGA",
            "DURIAN",
            "JAMBU",
            "KIWI",
            "MANGGA",
            "MELON",
            "STRAWBERY",
            "PISANG"

    };
    private static String[] fruitDetail = {
            "Apel adalah jenis buah-buahan, atau buah yang dihasilkan dari pohon buah apel. Buah apel biasanya berwarna merah kulitnya jika masak dan (siap dimakan), namun bisa juga kulitnya berwarna hijau atau kuning. Kulit buahnya agak lembek, daging buahnya keras. Buah ini memiliki beberapa biji di dalamnya.\n" +
                    "Orang mulai pertama kali menanam apel di Asia Tengah. ",
            "Anggur merupakan tanaman buah berupa perdu merambat yang termasuk ke dalam keluarga Vitaceae.[1] Buah ini biasanya digunakan untuk membuat jus anggur, jelly, minuman anggur, minyak biji anggur dan kismis, atau dimakan langsung.[1] Buah ini juga dikenal karena mengandung banyak senyawa polifenol dan resveratol yang berperan aktif dalam berbagai metabolisme tubuh, serta mampu mencegah terbentuknya sel kanker dan berbagai penyakit lainnya.[2]",
            "Buah naga (Inggris: Pitaya) adalah buah dari beberapa jenis kaktus dari marga Hylocereus dan Selenicereus. Buah ini berasal dari Meksiko, Amerika Tengah dan Amerika Selatan namun sekarang juga dibudidayakan di negara-negara Asia seperti Taiwan, Vietnam, Filipina, Indonesia dan Malaysia. Buah ini juga dapat ditemui di Okinawa, Israel, Australia utara dan Tiongkok selatan. Hylocereus hanya mekar pada malam hari.",
            "Durian adalah nama tumbuhan tropis yang berasal dari wilayah Asia Tenggara, sekaligus nama buahnya yang bisa dimakan. Nama ini diambil dari ciri khas kulit buahnya yang keras dan berlekuk-lekuk tajam sehingga menyerupai duri. Sebutan populernya adalah \"raja dari segala buah\" (King of Fruit). Durian adalah buah yang kontroversial, meskipun banyak orang yang menyukainya, tetapi sebagian yang lain malah muak dengan aromanya.",
            "Jambu biji ( Psidium guajava ) dikenal karena bagian tengah buahnya terdapat biji yang berkumpul  dan  berukuran kecil.  Tanaman  ini  berasal  dari  pulau-pulau  di  Laut  Karibia, daratan Amerika Tengah dan Amerika Selatan bagian utara.\n" +
                    "Jambu biji menyebar ke seluruh dunia, termasuk Indonesia, sejak ratusan tahun yang lalu, tepatnya setelah benua Amerika ditemukan. Saat ini, tanaman jambu biji telah dibudidayakan dan menyebar luar di daerah Sumatera dan Jawa, yang meliputi Sumatera Utara, DKI Jakarta,\n" +
                    "Jawa  Barat,  Jawa  Tengah,  DI  Yogyakarta  dan  Jawa  Timur",
            "Kiwi adalah sejenis buah beri yang dapat dimakan dari tanaman merambat berkayu dalam genus Actinidia. Actinidia asli berasal dari Shaanxi, Tiongkok.\n" +
                    "Buah kiwi yang normal berbentuk oval, kira-kira sebesar telur ayam (5–8 cm / 2–3 in dan diameter 4.5–5.5 cm / 1¾–2 ). Buah ini kaya serat, kulit berwarna hijau-kecokelatan dan daging buah berwarna hijau terang atau keemasan dengan biji kecil, hitam, dan bisa dimakan. Tekstur buah ini sangat halus dan rasanya yang unik, saat ini buah kiwi sudah ditanam di berbagai negara.\n",
            "Mangga atau mempelam adalah nama sejenis buah, demikian pula nama pohonnya. Mangga termasuk ke dalam marga Mangifera, yang terdiri dari 35-40 anggota dan suku Anacardiaceae. Pohon mangga termasuk tumbuhan tingkat tinggi yang struktur batangnya (habitus) termasuk kelompok arboreus, yaitu tumbuhan berkayu yang mempunyai tinggi batang lebih dari 5 m. Mangga bisa mencapai tinggi antara 10 hingga 40 m.",
            "Melon (Cucumis melo L.) merupakan nama buah sekaligus tanaman yang menghasilkannya, yang termasuk dalam suku labu-labuan atau Cucurbitaceae. Buahnya biasanya dimakan segar sebagai buah meja atau diiris-iris sebagai campuran es buah. Bagian yang dimakan adalah daging buah (mesokarp). Teksturnya lunak, berwarna putih sampai merah, tergantung kultivarnya.",
            "Stroberi atau tepatnya stroberi kebun (juga dikenal dengan nama arbei, dari bahasa Belanda aardbei) adalah sebuah varietas stroberi yang paling banyak dikenal di dunia. Seperti spesies lain dalam genus Fragaria (stroberi), buah ini berada dalam keluarga Rosaceae",
            "Pisang adalah nama umum yang diberikan pada tumbuhan terna raksasa berdaun besar memanjang dari suku Musaceae. Beberapa jenisnya (Musa acuminata, M. balbisiana, dan M. ×paradisiaca) menghasilkan buah konsumsi yang dinamakan sama. Buah ini tersusun dalam tandan dengan kelompok-kelompok tersusun menjari yang disebut sisir",


    };

    private static int[] photo = {
            R.drawable.apel,
            R.drawable.anggur,
            R.drawable.buah_naga,
            R.drawable.durian,
            R.drawable.jambu,
            R.drawable.kiwi,
            R.drawable.mangga,
            R.drawable.melon,
            R.drawable.strawberry,
            R.drawable.pisang

    };

    static ArrayList<FruitArchitecture> getListData() {
        ArrayList<FruitArchitecture> list = new ArrayList<>();
        for (int position = 0; position < fruitNickName.length; position++) {
            FruitArchitecture nw = new FruitArchitecture();
            nw.setFullName(fruitFullName[position]);
            nw.setNickName(fruitNickName[position]);
            nw.setDetail(fruitDetail[position]);
            nw.setPhoto(photo[position]);
            list.add(nw);
        }

        return list;
    }

}
