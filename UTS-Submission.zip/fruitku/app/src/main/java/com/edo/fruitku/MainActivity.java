package com.edo.fruitku;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rvFruit;
    private ArrayList<FruitArchitecture> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvFruit = findViewById(R.id.rv_fruit);
        rvFruit.setHasFixedSize(true);

        list.addAll(FruitsData.getListData());

        showRecyclerList();
    }

    private void showRecyclerList() {
        rvFruit.setLayoutManager(new LinearLayoutManager(this));
        ListFruit listFruit = new ListFruit(list);
        rvFruit.setAdapter(listFruit);

        listFruit.setOnItemClickCallback(new ListFruit.OnItemClickCallback() {
            @Override
            public void onItemClicked(FruitArchitecture data) {

                showSelectedData(data);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent about = new Intent(MainActivity.this, datadiri.class);
        startActivity(about);
        return super.onOptionsItemSelected(item);
    }

    public void showSelectedData(FruitArchitecture nw) {
        Intent detailIntent = new Intent(MainActivity.this, DetailFruit.class);
        detailIntent.putExtra(DetailFruit.EXTRA_IMG, nw.getPhoto());
        detailIntent.putExtra(DetailFruit.EXTRA_FULLNAME, nw.getFullName());
        detailIntent.putExtra(DetailFruit.EXTRA_NICKNAME, nw.getNickName());
        detailIntent.putExtra(DetailFruit.EXTRA_DETAIL, nw.getDetail());

        startActivity(detailIntent);
    }

}
